# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '3e476f75f701ca20389593ac0f2f0dd8d04672bc64b6c13b9f7ce1ce00a35f037dfef91b4bcdee47f763e2d9a02f0a964e09a22cab51831ab97729345b9035e4'