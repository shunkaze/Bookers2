Rails.application.routes.draw do
  devise_for :users
  root to: 'homes#top'
  get 'home/about', to: 'homes#about'
  resources :users, only: [:index, :show, :edit, :update]
  resources :books, only: [:new, :create, :index, :edit, :show, :update, :destroy]
  resources :post_images, only: [:new, :create, :index, :show, :destroy]
  get 'books/:id', to: 'books#show'
  delete 'books/:id', to: 'books#destroy'
  post 'books', to: 'books#create'
end
