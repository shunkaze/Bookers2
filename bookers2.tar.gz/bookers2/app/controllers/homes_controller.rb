class HomesController < ApplicationController
  def top
  end

  def about
  end
  
  def show
    @user = User.find(parqms[:id])
  end
end
